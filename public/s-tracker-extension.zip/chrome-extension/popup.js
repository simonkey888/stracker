// ════════════════════════════════════════════════════════════════
// S-TRACKER — Popup Script (v2 — fixed)
// ════════════════════════════════════════════════════════════════

const DEFAULT_API = 'http://localhost:3000/api/ingest'
const CONFIG_API = 'http://localhost:3000/api/extension-config'

const $ = (id) => document.getElementById(id)

const sDot = $('sDot'), sVal = $('sVal')
const mDot = $('mDot'), mVal = $('mVal')
const entityIdInput = $('entityId')
const apiUrlInput = $('apiUrl')
const toggle = $('toggle')
const btnSend = $('btnSend')
const sigBox = $('sigBox'), sigCoords = $('sigCoords'), sigMeta = $('sigMeta')

// ── AUTO-CONFIG: Fetch entity ID from server ──

async function autoConfig() {
  const cfg = await chrome.storage.local.get(['entityId', 'apiUrl', 'enabled', 'lastSignal'])

  // If entityId already set, don't overwrite
  if (cfg.entityId) {
    entityIdInput.value = cfg.entityId
    apiUrlInput.value = cfg.apiUrl || DEFAULT_API
    toggle.classList.toggle('on', cfg.enabled !== false)
    if (cfg.lastSignal) showSignal(cfg.lastSignal)
    refreshStatus()
    return
  }

  // Try to auto-fetch entity ID from the server
  try {
    const res = await fetch(CONFIG_API)
    if (res.ok) {
      const data = await res.json()
      if (data.entityId) {
        entityIdInput.value = data.entityId
        await chrome.storage.local.set({ entityId: data.entityId })
        console.log('[S-Tracker] Auto-configured entityId:', data.entityId)
      }
    }
  } catch (err) {
    console.warn('[S-Tracker] Auto-config failed (server not reachable):', err.message)
  }

  apiUrlInput.value = cfg.apiUrl || DEFAULT_API
  toggle.classList.toggle('on', cfg.enabled !== false)
  if (cfg.lastSignal) showSignal(cfg.lastSignal)
  refreshStatus()
}

autoConfig()

// ── STATUS ──

function refreshStatus() {
  chrome.runtime.sendMessage({ type: 'GET_STATUS' }, (s) => {
    if (chrome.runtime.lastError || !s) {
      sDot.className = 'dot dot-r'; sVal.textContent = 'Error'
      return
    }
    if (s.configured && s.enabled) {
      sDot.className = 'dot dot-g'; sVal.textContent = 'Activo'
    } else if (!s.configured) {
      sDot.className = 'dot dot-y'; sVal.textContent = 'Sin Entity ID'
    } else {
      sDot.className = 'dot dot-m'; sVal.textContent = 'Pausado'
    }
  })

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const url = tabs[0]?.url || ''
    const isMaps = /google\.com\/maps|maps\.google|maps\.app\.goo\.gl|goo\.gl\/maps/.test(url)
    mDot.className = `dot ${isMaps ? 'dot-g' : 'dot-m'}`
    mVal.textContent = isMaps ? 'Detectado' : 'No detectado'
  })
}

// ── SAVE CONFIG ──

entityIdInput.addEventListener('change', () => {
  const val = entityIdInput.value.trim()
  // Validate: Entity ID should NOT be a URL
  if (val.startsWith('http') || val.includes('goo.gl') || val.includes('google')) {
    alert('⚠️ Eso es una URL, no un Entity ID.\n\nEl Entity ID es un código como: cmq2hdfn80000q1s1sc7knmyu\n\nLo encontrás en la app → Link → Chrome Extension → Entity ID')
    entityIdInput.value = ''
    return
  }
  chrome.storage.local.set({ entityId: val })
  refreshStatus()
})

apiUrlInput.addEventListener('change', () => {
  chrome.storage.local.set({ apiUrl: apiUrlInput.value.trim() })
  refreshStatus()
})

toggle.addEventListener('click', () => {
  const on = toggle.classList.toggle('on')
  chrome.storage.local.set({ enabled: on })
  refreshStatus()
})

// ── SEND LOCATION ──

btnSend.addEventListener('click', async () => {
  btnSend.textContent = 'ENVIANDO...'
  btnSend.disabled = true
  btnSend.className = 'btn-send'

  // Get active tab
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true })
  const url = tabs[0]?.url

  if (!url || !/google\.com\/maps|maps\.google|maps\.app\.goo\.gl|goo\.gl\/maps/.test(url)) {
    btnSend.textContent = 'NO ES GOOGLE MAPS'
    btnSend.className = 'btn-send err'
    setTimeout(resetBtn, 2500)
    return
  }

  // Extract coords from URL
  const patterns = [
    /@(-?\d+\.\d+),(-?\d+\.\d+)/,
    /!3d(-?\d+\.\d+)!4d(-?\d+\.\d+)/,
    /[?&]q=(-?\d+\.\d+),(-?\d+\.\d+)/,
    /[?&]center=(-?\d+\.\d+),(-?\d+\.\d+)/,
  ]

  let coords = null
  for (const p of patterns) {
    const m = url.match(p)
    if (m) {
      const lat = parseFloat(m[1]), lng = parseFloat(m[2])
      if (lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180) {
        coords = { lat, lng }
        break
      }
    }
  }

  if (!coords) {
    btnSend.textContent = 'SIN COORDS EN URL'
    btnSend.className = 'btn-send err'
    setTimeout(resetBtn, 2500)
    return
  }

  // Get config
  const cfg = await chrome.storage.local.get(['entityId', 'apiUrl'])
  if (!cfg.entityId) {
    btnSend.textContent = 'FALTA ENTITY ID'
    btnSend.className = 'btn-send err'
    setTimeout(resetBtn, 2500)
    return
  }

  // Validate Entity ID format
  if (cfg.entityId.startsWith('http') || cfg.entityId.includes('goo.gl')) {
    btnSend.textContent = 'ENTITY ID INVÁLIDO (es URL)'
    btnSend.className = 'btn-send err'
    setTimeout(resetBtn, 3000)
    return
  }

  const apiUrl = cfg.apiUrl || DEFAULT_API

  console.log('[S-Tracker] Sending to:', apiUrl)
  console.log('[S-Tracker] Payload:', { entityId: cfg.entityId, lat: coords.lat, lng: coords.lng })

  // Send to ingest API
  try {
    const res = await fetch(apiUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        entityId: cfg.entityId,
        lat: coords.lat,
        lng: coords.lng,
        accuracy: 10,
        source: 'chrome_ext',
        metadata: {
          url: url.substring(0, 300),
          extractionMethod: 'manual_capture',
        },
      }),
    })

    const data = await res.json()
    console.log('[S-Tracker] Response:', res.status, data)

    if (data.ok) {
      btnSend.textContent = '✓ SEÑAL ENVIADA'
      btnSend.className = 'btn-send ok'
      showSignal({
        lat: coords.lat,
        lng: coords.lng,
        confidence: data.confidence?.score ?? 0,
        time: new Date().toISOString(),
      })
    } else {
      // Show the actual error from the server
      const errMsg = data.error || `Error ${res.status}`
      btnSend.textContent = errMsg.substring(0, 25)
      btnSend.className = 'btn-send err'
    }
  } catch (err) {
    console.error('[S-Tracker] Network error:', err)
    btnSend.textContent = 'SIN CONEXIÓN AL SERVER'
    btnSend.className = 'btn-send err'
  }

  setTimeout(resetBtn, 3000)
})

function resetBtn() {
  btnSend.textContent = 'SEND LOCATION'
  btnSend.disabled = false
  btnSend.className = 'btn-send'
}

function showSignal(s) {
  sigBox.style.display = 'block'
  sigCoords.textContent = `${s.lat.toFixed(6)}, ${s.lng.toFixed(6)}`
  const conf = typeof s.confidence === 'number' ? s.confidence.toFixed(2) : '—'
  const time = new Date(s.time).toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
  sigMeta.textContent = `conf: ${conf} · ${time}`
  chrome.storage.local.set({ lastSignal: s })
}
