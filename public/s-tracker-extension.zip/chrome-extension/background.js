// ════════════════════════════════════════════════════════════════
// S-TRACKER — Background Service Worker (MV3) — v2
// ════════════════════════════════════════════════════════════════

const DEFAULT_API = 'http://localhost:3000/api/ingest'
const THROTTLE_MS = 10_000

// ── COORD EXTRACTION ──

const URL_PATTERNS = [
  /@(-?\d+\.\d+),(-?\d+\.\d+)/,
  /!3d(-?\d+\.\d+)!4d(-?\d+\.\d+)/,
  /[?&]q=(-?\d+\.\d+),(-?\d+\.\d+)/,
  /[?&]center=(-?\d+\.\d+),(-?\d+\.\d+)/,
  /\/search\/(-?\d+\.\d+),(-?\d+\.\d+)/,
  /dir\/(-?\d+\.\d+),(-?\d+\.\d+)/,
  /!3d(-?\d+\.\d+).*!2d(-?\d+\.\d+)/,
]

function extractCoords(url) {
  for (const p of URL_PATTERNS) {
    const m = url.match(p)
    if (m) {
      const lat = parseFloat(m[1]), lng = parseFloat(m[2])
      if (lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180)
        return { lat, lng }
    }
  }
  return null
}

function extractPlace(url) {
  const m = url.match(/\/place\/([^/@]+)/)
  return m ? decodeURIComponent(m[1].replace(/\+/g, ' ')) : null
}

function isMapsUrl(url) {
  return /google\.com\/maps|maps\.google\.com|maps\.app\.goo\.gl|goo\.gl\/maps/.test(url)
}

// ── INGEST ──

async function ingest(lat, lng, rawUrl, method) {
  const cfg = await chrome.storage.local.get(['apiUrl', 'entityId', 'enabled'])
  if (cfg.enabled === false) return null

  // Validate entityId
  if (!cfg.entityId) {
    console.warn('[S-Tracker] ❌ Falta entityId — abrí el popup y configurá')
    return null
  }
  if (cfg.entityId.startsWith('http') || cfg.entityId.includes('goo.gl')) {
    console.error('[S-Tracker] ❌ entityId parece una URL, no un ID válido:', cfg.entityId)
    return null
  }

  const apiUrl = cfg.apiUrl || DEFAULT_API
  const place = extractPlace(rawUrl)

  const payload = {
    entityId: cfg.entityId,
    lat,
    lng,
    accuracy: method === 'app_state' ? 5 : 10,
    source: 'chrome_ext',
    metadata: {
      url: rawUrl.substring(0, 300),
      placeName: place,
      extractionMethod: method,
    },
  }

  console.log('[S-Tracker] 📤 Enviando:', JSON.stringify(payload, null, 2))

  try {
    const res = await fetch(apiUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    })

    const data = await res.json()
    console.log('[S-Tracker] 📥 Response:', res.status, JSON.stringify(data))

    if (!res.ok) {
      console.error('[S-Tracker] ❌ Ingest failed:', res.status, data.error)
      return null
    }

    // Guardar última señal para el popup
    await chrome.storage.local.set({
      lastSignal: {
        lat, lng, place,
        confidence: data.confidence?.score ?? 0,
        sightingId: data.sighting?.id,
        time: new Date().toISOString(),
      },
    })

    console.log('[S-Tracker] ✓ Signal ingested:', data.sighting?.id, 'conf:', data.confidence?.score)
    return data
  } catch (err) {
    console.error('[S-Tracker] ❌ Network error:', err.message)
    console.error('[S-Tracker] → ¿El server está corriendo en', apiUrl, '?')
    return null
  }
}

// ── THROTTLED CAPTURE ──

let lastCapture = 0

async function maybeCapture(url, tabId) {
  const now = Date.now()
  if (now - lastCapture < THROTTLE_MS) return

  const coords = extractCoords(url)
  if (!coords) {
    console.log('[S-Tracker] No coords in URL:', url.substring(0, 80))
    return
  }

  console.log('[S-Tracker] 📍 Coords found:', coords.lat.toFixed(6), coords.lng.toFixed(6))
  lastCapture = now
  await ingest(coords.lat, coords.lng, url, 'bg_url_regex')
}

// ── EVENT LISTENERS ──

// 1. Tab URL cambia
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.url && isMapsUrl(info.url)) {
    maybeCapture(info.url, tabId)
  }
})

// 2. Navigation completed (SPA)
chrome.webNavigation.onCompleted.addListener((details) => {
  if (details.frameId !== 0) return
  if (isMapsUrl(details.url)) {
    maybeCapture(details.url, details.tabId)
  }
})

// 3. Short link redirect
chrome.webRequest.onBeforeRedirect.addListener(
  (details) => {
    if (details.redirectUrl && isMapsUrl(details.redirectUrl)) {
      console.log('[S-Tracker] 🔗 Short link resolved →', details.redirectUrl.substring(0, 80))
      maybeCapture(details.redirectUrl, details.tabId)
    }
  },
  { urls: ['https://maps.app.goo.gl/*', 'https://goo.gl/maps/*'] }
)

// 4. Messages from content script and popup
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'INGEST_SIGNAL') {
    ingest(msg.lat, msg.lng, msg.rawUrl, msg.method).then((result) => {
      sendResponse(result || { ok: false })
    })
    return true
  }

  if (msg.type === 'CAPTURE_NOW') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const url = tabs[0]?.url
      if (!url || !isMapsUrl(url)) {
        sendResponse({ ok: false, error: 'No es Google Maps' })
        return
      }
      const coords = extractCoords(url)
      if (!coords) {
        sendResponse({ ok: false, error: 'Sin coordenadas en URL' })
        return
      }
      lastCapture = 0 // Reset throttle for manual
      ingest(coords.lat, coords.lng, url, 'manual_capture').then((result) => {
        sendResponse(result || { ok: false })
      })
    })
    return true
  }

  if (msg.type === 'GET_STATUS') {
    chrome.storage.local.get(['entityId', 'enabled', 'apiUrl', 'lastSignal'], (cfg) => {
      sendResponse({
        configured: !!cfg.entityId && !cfg.entityId.startsWith('http'),
        enabled: cfg.enabled !== false,
        apiUrl: cfg.apiUrl || DEFAULT_API,
        entityId: cfg.entityId || null,
        lastSignal: cfg.lastSignal || null,
      })
    })
    return true
  }
})

console.log('[S-Tracker] Background service worker started')
