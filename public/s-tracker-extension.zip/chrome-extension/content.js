// ════════════════════════════════════════════════════════════════
// S-TRACKER — Content Script
// ════════════════════════════════════════════════════════════════
//
// Corre dentro de Google Maps.
// Extrae coords de: URL → app state → page title.
// Detecta SPA navigation (pushState/replaceState).
// Envía señales al background worker.
//
// NO cookies. NO full page content. Solo coords.
// ════════════════════════════════════════════════════════════════

// ── EXTRACTION METHODS (ordered by reliability) ──

function extractFromUrl() {
  const url = window.location.href
  const patterns = [
    /@(-?\d+\.\d+),(-?\d+\.\d+)/,
    /!3d(-?\d+\.\d+)!4d(-?\d+\.\d+)/,
    /[?&]q=(-?\d+\.\d+),(-?\d+\.\d+)/,
    /[?&]center=(-?\d+\.\d+),(-?\d+\.\d+)/,
    /!3d(-?\d+\.\d+).*!2d(-?\d+\.\d+)/,
  ]
  for (const p of patterns) {
    const m = url.match(p)
    if (m) {
      const lat = parseFloat(m[1]), lng = parseFloat(m[2])
      if (lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180)
        return { lat, lng, method: 'content_url' }
    }
  }
  return null
}

function extractFromAppState() {
  try {
    // Google Maps stores center in data-app-state attribute
    const el = document.querySelector('[data-app-state]')
    if (el) {
      const raw = el.getAttribute('data-app-state')
      if (raw) {
        const s = JSON.parse(raw)
        if (s?.center?.lat != null && s?.center?.lng != null) {
          return { lat: s.center.lat, lng: s.center.lng, method: 'app_state' }
        }
      }
    }
  } catch { /* ignore */ }
  return null
}

function extractFromTitle() {
  const m = document.title.match(/(-?\d+\.\d+)[°\s,]+(-?\d+\.\d+)/)
  if (m) {
    const lat = parseFloat(m[1]), lng = parseFloat(m[2])
    if (lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180)
      return { lat, lng, method: 'page_title' }
  }
  return null
}

function extractCoords() {
  return extractFromAppState() || extractFromUrl() || extractFromTitle()
}

// ── CAPTURE LOGIC ──

let lastUrl = ''

function checkAndCapture() {
  const url = window.location.href
  if (url === lastUrl) return

  const coords = extractCoords()
  if (!coords) return

  lastUrl = url

  chrome.runtime.sendMessage({
    type: 'INGEST_SIGNAL',
    lat: coords.lat,
    lng: coords.lng,
    rawUrl: url,
    method: coords.method,
  })
}

// ── SPA NAVIGATION DETECTION ──

// Google Maps is a SPA — URL changes via pushState/replaceState
const origPush = history.pushState
const origReplace = history.replaceState

history.pushState = function () {
  origPush.apply(this, arguments)
  setTimeout(checkAndCapture, 500)
}

history.replaceState = function () {
  origReplace.apply(this, arguments)
  setTimeout(checkAndCapture, 500)
}

// Also poll every 5s as fallback
setInterval(checkAndCapture, 5000)

// Initial capture after page settles
setTimeout(checkAndCapture, 2000)

console.log('[S-Tracker] Content script loaded on Google Maps')
